dist\exe\app
