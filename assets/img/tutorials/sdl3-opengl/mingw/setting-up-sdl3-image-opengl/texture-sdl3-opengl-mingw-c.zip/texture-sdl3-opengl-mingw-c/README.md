# texture-sdl3-opengl-mingw-c

A project template demonstrating how to load textures using **SDL3_image** and render them onto a hardware-accelerated primitive using **OpenGL 3.3 Core Profile** and **GLAD** on Windows (MinGW / CMake).

## 📖 Full Tutorial

For step-by-step instructions on downloading libraries, structuring folders, setting up your environment variables, and configuring CMake, check out the complete guide:

👉 **[Setting up SDL3_image with OpenGL (MinGW)](https://ivan-enzhaev.github.io/tutorials/sdl3-opengl/mingw/setting-up-sdl3-image-opengl-mingw/?lang=en)**

*Читать на русском:* **[Настройка SDL3_image с OpenGL (MinGW)](https://ivan-enzhaev.github.io/tutorials/sdl3-opengl/mingw/setting-up-sdl3-image-opengl-mingw/?lang=ru)**

---

## 🚀 Quick Start

If your local environment is already configured, you can build and run this project immediately by following these steps:

### 1. Requirements & Paths
Ensure that you have extracted the required dependencies into the exact paths specified below:

*   **SDL3 Core:** `C:/libs/SDL3-devel-3.4.8-mingw`
*   **SDL3_image Development:** `C:/libs/SDL3_image-devel-3.4.4-mingw`
*   **SDL3_image Runtime:** `C:/libs/SDL3_image-3.4.4-win32-x64` 
    *(Make sure this directory is added to your User **Path** environment variable so the executable can find the necessary `.dll` files at runtime)*
*   **GLAD (OpenGL 3.3 Core):** `C:/libs/glad-0.1.36/opengl-3.3`

### 2. Project Directory Structure
```text
texture-sdl3-opengl-mingw-c/
├── CMakeLists.txt
├── assets/
│   └── images/
│       └── right-arrow.png
└── src/
    └── main.c
