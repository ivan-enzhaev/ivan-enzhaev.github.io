#define SDL_MAIN_USE_CALLBACKS 1 // Use the callbacks instead of main()

#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_mixer/SDL_mixer.h>
#include <glad/glad.h>

static SDL_Window *window = NULL;
static SDL_GLContext glContext;

static MIX_Mixer *mixer = NULL;
static MIX_Audio *backgroundMusic = NULL;
static MIX_Audio *soundEffect = NULL;
static MIX_Track *musicTrack = NULL;
static MIX_Track *sfxTrack = NULL;

static const size_t canvasWidth = 430;
static const size_t canvasHeight = 430;

// This function runs once at startup
SDL_AppResult SDL_AppInit(void **appState, int argc, char *argv[])
{
    if (!SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO))
    {
        SDL_Log("Couldn't initialize SDL: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    // Initialize Mixer 3 subsystem
    if (!MIX_Init())
    {
        SDL_Log("Couldn't initialize SDL_mixer: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    // Create the central Mixer Device
    mixer = MIX_CreateMixerDevice(SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK, NULL);
    if (!mixer)
    {
        SDL_Log("Mixer creation failed: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);

    const char *title = "SDL3_mixer OpenGL";
    window = SDL_CreateWindow(title, canvasWidth, canvasHeight, SDL_WINDOW_OPENGL);
    if (!window)
    {
        SDL_Log("Couldn't create the window: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    glContext = SDL_GL_CreateContext(window);
    if (!glContext)
    {
        SDL_Log("Couldn't create the glContext: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    SDL_GL_SetSwapInterval(1); // Turn on vertical sync

    if (!gladLoadGLLoader((GLADloadproc)SDL_GL_GetProcAddress))
    {
        SDL_Log("Failed to initialize OpenGL function pointers");
        return SDL_APP_FAILURE;
    }

    glClearColor(0.15f, 0.15f, 0.18f, 1.0f);

    // Load Audio Objects (using 'true' to cache data in memory)
    backgroundMusic = MIX_LoadAudio(mixer, "assets/audio/Winds Of Stories.ogg", true);
    if (!backgroundMusic)
    {
        SDL_Log("Failed to load music: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    soundEffect = MIX_LoadAudio(mixer, "assets/audio/Picked Coin Echo 2.wav", true);
    if (!soundEffect)
    {
        SDL_Log("Failed to load sound effect: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    // Allocate dedicated playback tracks
    musicTrack = MIX_CreateTrack(mixer);
    sfxTrack = MIX_CreateTrack(mixer);
    if (!musicTrack || !sfxTrack)
    {
        SDL_Log("Failed to create playback tracks");
        return SDL_APP_FAILURE;
    }

    // Setup and stream background music infinitely
    MIX_SetTrackAudio(musicTrack, backgroundMusic);
    MIX_SetTrackLoops(musicTrack, -1); // -1 loops infinitely, 0 disables looping
    MIX_PlayTrack(musicTrack, -1);

    return SDL_APP_CONTINUE;
}

// This function runs when a new event occurs
SDL_AppResult SDL_AppEvent(void *appState, SDL_Event *event)
{
    switch (event->type)
    {
        case SDL_EVENT_QUIT:
            return SDL_APP_SUCCESS;
        case SDL_EVENT_KEY_DOWN:
            if (event->key.key == SDLK_SPACE)
            {
                // Instantly bind and fire the one-shot sound effect (0 additional loops)
                MIX_SetTrackAudio(sfxTrack, soundEffect);
                MIX_PlayTrack(sfxTrack, 0);
            }
            break;
        default:
            break;
    }
    return SDL_APP_CONTINUE;
}

// This function runs once per frame
SDL_AppResult SDL_AppIterate(void *appState)
{
    glClear(GL_COLOR_BUFFER_BIT);

    // Context rendering logic goes here (OpenGL 3.3 pipeline)

    SDL_GL_SwapWindow(window);
    return SDL_APP_CONTINUE;
}

// This function runs once at shutdown
void SDL_AppQuit(void *appState, SDL_AppResult result)
{
    /*
       In SDL_mixer 3, MIX_Quit() handles garbage collection, freeing
       all mixer devices, loaded audio chunks, and track configurations automatically.
    */
    MIX_Quit();

    SDL_GL_DestroyContext(glContext);
    SDL_DestroyWindow(window);
    SDL_Quit();
}
