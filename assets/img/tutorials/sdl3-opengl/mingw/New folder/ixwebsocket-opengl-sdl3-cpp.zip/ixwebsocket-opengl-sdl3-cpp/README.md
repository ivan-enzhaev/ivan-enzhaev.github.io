# ixwebsocket-opengl-sdl3-cpp

A project template demonstrating how to integrate the `IXWebSocket` library with an SDL3 windowing context and an OpenGL 3.3 core profile renderer on Windows using MinGW 13.1 and CMake.

## 📖 Full Tutorial

For complete step-by-step instructions, details on compiling dependencies (`MbedTLS`, `zlib`), and a breakdown of the non-blocking network event loop thread, follow the full guide here:

👉 **[Setting up IXWebSocket with SDL3 and OpenGL (MinGW)](https://ivan-enzhaev.github.io/tutorials/sdl3-opengl/mingw/setting-up-ixwebsocket-sdl3-opengl-mingw/?lang=en)**

*Читать на русском:* **[Настройка IXWebSocket с SDL3 и OpenGL (MinGW)](https://ivan-enzhaev.github.io/tutorials/sdl3-opengl/mingw/setting-up-ixwebsocket-sdl3-opengl-mingw/?lang=ru)**

---

## 📁 Project Structure

```text
ixwebsocket-opengl-sdl3-cpp/
├── CMakeLists.txt
├── server/
│   └── server.js
└── src/
    └── main.cpp