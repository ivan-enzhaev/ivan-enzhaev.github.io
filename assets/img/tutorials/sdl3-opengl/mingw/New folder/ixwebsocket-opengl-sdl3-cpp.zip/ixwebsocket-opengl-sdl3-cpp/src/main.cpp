#define SDL_MAIN_USE_CALLBACKS 1

#include <glad/glad.h>
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>

#include <ixwebsocket/IXNetSystem.h> // Required header for Network Init
#include <ixwebsocket/IXWebSocket.h>
#include <iostream>

struct AppContext
{
    SDL_Window *window;
    SDL_GLContext glContext;
    ix::WebSocket webSocket;
};

SDL_AppResult SDL_AppInit(void **appstate, int argc, char *argv[])
{
    // Initialize the network subsystem for Windows (Winsock)
    ix::initNetSystem();

    if (!SDL_Init(SDL_INIT_VIDEO))
    {
        std::cerr << "Failed to init SDL Video" << std::endl;
        ix::uninitNetSystem();
        return SDL_APP_FAILURE;
    }

    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);

    SDL_Window *window =SDL_CreateWindow("SDL3 + IXWebSocket", 380, 380, SDL_WINDOW_OPENGL);
    if (!window)
    {
        ix::uninitNetSystem();
        return SDL_APP_FAILURE;
    }

    SDL_GLContext glContext =SDL_GL_CreateContext(window);
    if (!glContext)
    {
        ix::uninitNetSystem();
        return SDL_APP_FAILURE;
    }

    if (!gladLoadGLLoader((GLADloadproc)SDL_GL_GetProcAddress))
    {
        std::cerr << "Failed to init GLAD" << std::endl;
        SDL_GL_DestroyContext(glContext);
        SDL_DestroyWindow(window);
        ix::uninitNetSystem();
        return SDL_APP_FAILURE;
    }

    SDL_GL_SetSwapInterval(1);

    // Allocate the state onto the heap and pass it to SDL
    AppContext *app = new AppContext();
    app->window = window;
    app->glContext = glContext;
    *appstate = app;

    // IXWebSocket Network Initialization
    std::string url("ws://localhost:3000");
    app->webSocket.setUrl(url);

    app->webSocket.setOnMessageCallback([app](const ix::WebSocketMessagePtr &msg) {
        if (msg->type == ix::WebSocketMessageType::Message)
        {
            std::cout << "Received: " << msg->str << std::endl;
        }
        else if (msg->type == ix::WebSocketMessageType::Open)
        {
            std::cout << "Connected to WebSocket Server!" << std::endl;
            app->webSocket.send("Hello from SDL3 Client!");
        }
        else if (msg->type == ix::WebSocketMessageType::Close)
        {
            std::cout << "Disconnected from Server" << std::endl;
        }
        else if (msg->type == ix::WebSocketMessageType::Error)
        {
            std::cerr << "Error: " << msg->errorInfo.reason << std::endl;
        }
    });

    std::cout << "Connecting to " << url << "..." << std::endl;
    app->webSocket.start(); // Non-blocking background worker thread

    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppEvent(void *appstate, SDL_Event *event)
{
    if (event->type == SDL_EVENT_QUIT)
    {
        return SDL_APP_SUCCESS;
    }
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppIterate(void *appstate)
{
    AppContext *app = (AppContext *)appstate;

    // Render loop backdrop updates
    glClearColor(0.15f, 0.15f, 0.15f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    SDL_GL_SwapWindow(app->window);
    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void *appstate, SDL_AppResult result)
{
    AppContext *app = (AppContext *)appstate;
    if (app)
    {
        app->webSocket.stop(); // Cleanly stop background socket thread
        SDL_GL_DestroyContext(app->glContext);
        SDL_DestroyWindow(app->window);
        delete app; // Free allocated memory
    }

    // Clean up Windows socket resources on exit
    ix::uninitNetSystem();

    SDL_Quit();
    std::cout << "Application exited cleanly." << std::endl;
}
