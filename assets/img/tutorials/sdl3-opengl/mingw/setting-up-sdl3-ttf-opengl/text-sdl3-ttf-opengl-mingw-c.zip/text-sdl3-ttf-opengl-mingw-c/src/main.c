#define SDL_MAIN_USE_CALLBACKS 1 // Use the callbacks instead of main()

#include <glad/glad.h>

#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <cglm/cglm.h>

static SDL_Window *window = NULL;
static SDL_GLContext glContext;
static TTF_Font *font = NULL;
static GLuint textTexture = 0;
static int textW = 0, textH = 0;
static GLuint shaderProgram, vao, vbo;

static const size_t canvasWidth = 430;
static const size_t canvasHeight = 430;

static GLint projLoc;
static GLint modelLoc;

const char *vertexShaderSource =
    "#version 330 core\n"
    "layout (location = 0) in vec4 aVertex; // <vec2 pos, vec2 tex>\n"
    "out vec2 vTexCoord;\n"
    "uniform mat4 projection;\n"
    "uniform mat4 model;\n"
    "void main()\n"
    "{\n"
    "    gl_Position = projection * model * vec4(aVertex.xy, 0.0, 1.0);\n"
    "    vTexCoord = aVertex.zw;\n"
    "}\n";

const char *fragmentShaderSource =
    "#version 330 core\n"
    "precision mediump float;\n"
    "in vec2 vTexCoord;\n"
    "out vec4 fragColor;\n"
    "uniform sampler2D textSampler;\n"
    "void main()\n"
    "{\n"
    "    fragColor = texture(textSampler, vTexCoord);\n"
    "}\n";

static GLuint createTextureFromSurface(SDL_Surface *surface)
{
    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, surface->w, surface->h, 0, GL_RGBA, GL_UNSIGNED_BYTE, surface->pixels);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    return texture;
}

// This function runs once at startup
SDL_AppResult SDL_AppInit(void **appState, int argc, char *argv[])
{
    if (!SDL_Init(SDL_INIT_VIDEO))
    {
        SDL_Log("Couldn't initialize SDL: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    if (!TTF_Init())
    {
        SDL_Log("Couldn't initialize SDL_ttf: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 1); // Enable MULTISAMPLE
    SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES, 4); // can be 2, 4, 8 or 16

    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);

    const char *title = "SDL3_ttf OpenGL";
    window = SDL_CreateWindow(title, canvasWidth, canvasHeight, SDL_WINDOW_OPENGL);
    if (!window)
    {
        SDL_Log("Couldn't create the window: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    glContext = SDL_GL_CreateContext(window);
    if (!glContext)
    {
        SDL_Log("Couldn't create the glContext: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    SDL_GL_SetSwapInterval(1); // Turn on vertical sync

    // Load standard Desktop GLAD mapping
    if (!gladLoadGLLoader((GLADloadproc)SDL_GL_GetProcAddress))
    {
        SDL_Log("Failed to initialize OpenGL function pointers");
        return SDL_APP_FAILURE;
    }

    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);

    int w, h;
    SDL_GetWindowSize(window, &w, &h);
    glViewport(0, 0, w, h);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Shader Setup
    GLuint vs = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vs, 1, &vertexShaderSource, NULL);
    glCompileShader(vs);
    GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fs, 1, &fragmentShaderSource, NULL);
    glCompileShader(fs);
    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vs);
    glAttachShader(shaderProgram, fs);
    glLinkProgram(shaderProgram);
    glUseProgram(shaderProgram);

    // GLint success;
    // glGetShaderiv(vs, GL_COMPILE_STATUS, &success);
    // if (!success)
    // {
    //     char infoLog[512];
    //     glGetShaderInfoLog(vs, 512, NULL, infoLog);
    //     SDL_Log("Shader Error: %s", infoLog);
    // }

    // Load Font
    font = TTF_OpenFont("assets/fonts/LiberationSans-Regular.ttf", 36.0f);
    if (!font)
    {
        SDL_Log("Font error: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    // Render text to surface, then to GL texture
    SDL_Color color = { 170, 255, 195, 255 };
    SDL_Surface *s = TTF_RenderText_Blended_Wrapped(font, "Hello, OpenGL!\n\nПривет, OpenGL!", 0, color, 0);
    if (s)
    {
        // Convert surface to a guaranteed RGBA format
        SDL_Surface *converted = SDL_ConvertSurface(s, SDL_PIXELFORMAT_RGBA32);
        SDL_DestroySurface(s); // Free the original

        if (converted)
        {
            textW = converted->w;
            textH = converted->h;
            textTexture = createTextureFromSurface(converted);
            SDL_DestroySurface(converted);
        }
    }

    // VAO/VBO Setup (Unit Quad 0.0 to 1.0)
    float verts[] = {
        // x, y, u, v
        0.0f, 1.0f, 0.0f, 1.0f,
        1.0f, 0.0f, 1.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 0.0f,

        0.0f, 1.0f, 0.0f, 1.0f,
        1.0f, 1.0f, 1.0f, 1.0f,
        1.0f, 0.0f, 1.0f, 0.0f
    };
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void *)0);
    glEnableVertexAttribArray(0);

    projLoc = glGetUniformLocation(shaderProgram, "projection");
    modelLoc = glGetUniformLocation(shaderProgram, "model");

    return SDL_APP_CONTINUE;
}

// This function runs when a new event (mouse input, keypresses, etc) occurs
SDL_AppResult SDL_AppEvent(void *appState, SDL_Event *event)
{
    switch (event->type)
    {
        case SDL_EVENT_QUIT:
        {
            return SDL_APP_SUCCESS;
            break;
        }
        default:
            break;
    }
    return SDL_APP_CONTINUE;
}

// This function runs once per frame, and is the heart of the program
SDL_AppResult SDL_AppIterate(void *appState)
{
    glClear(GL_COLOR_BUFFER_BIT);

    // Projection Matrix
    mat4 proj;
    glm_ortho(0.0f, (float)canvasWidth, (float)canvasHeight, 0.0f, -1.0f, 1.0f, proj);

    // Model matrix
    mat4 model;
    glm_mat4_identity(model);
    vec3 pos = { 20.0f, 100.f, 0.0f };
    glm_translate(model, pos); // Setting position with cglm
    vec3 scale = { (float)textW, (float)textH, 1.0f };
    glm_scale(model, scale); // Setting size with cglm

    glUniformMatrix4fv(projLoc, 1, GL_FALSE, (float *)proj);
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, (float *)model);

    glBindTexture(GL_TEXTURE_2D, textTexture);
    glBindVertexArray(vao);
    glDrawArrays(GL_TRIANGLES, 0, 6);

    SDL_GL_SwapWindow(window);
    return SDL_APP_CONTINUE;
}

// This function runs once at shutdown
void SDL_AppQuit(void *appState, SDL_AppResult result)
{
    glDeleteTextures(1, &textTexture);
    TTF_CloseFont(font);
    TTF_Quit();
    SDL_GL_DestroyContext(glContext);
    SDL_DestroyWindow(window);
}
