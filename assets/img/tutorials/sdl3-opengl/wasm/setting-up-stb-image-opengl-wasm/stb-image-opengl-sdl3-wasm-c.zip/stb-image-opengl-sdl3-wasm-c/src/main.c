#define SDL_MAIN_USE_CALLBACKS 1 // Use callback functions instead of main()

#include <GLES3/gl3.h>
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>

#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

typedef struct
{
    SDL_Window *window;
    SDL_GLContext glContext;
    GLuint shaderProgram;
    GLuint VAO, VBO, EBO;
    GLuint textureID; // Added for the image
} App;

const char *vertexShaderSource =
    "#version 300 es\n"
    "layout (location = 0) in vec3 aPosition;\n"
    "layout (location = 1) in vec2 aTexCoord;\n"
    "out vec2 vTexCoord;\n"
    "void main()\n"
    "{\n"
    "    gl_Position = vec4(aPosition, 1.0);\n"
    "    vTexCoord = aTexCoord;\n"
    "}\n";

const char *fragmentShaderSource =
    "#version 300 es\n"
    "precision mediump float;\n"
    "in vec2 vTexCoord;\n"
    "uniform sampler2D ourTexture;\n"
    "out vec4 fragColor;\n"
    "void main()\n"
    "{\n"
    "    fragColor = texture(ourTexture, vTexCoord);\n"
    "}\n";

GLuint createTexture(const char *path)
{
    int h_image, w_image, cnt;
    unsigned char *data = stbi_load(path, &w_image, &h_image, &cnt, 0);
    if (data == NULL)
    {
        SDL_Log("Failed to load the image: %s", path);
        return 0;
    }

    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        // For pixel graphics: GL_NEAREST
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w_image, h_image, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    }

    stbi_image_free(data);

    return texture;
}

SDL_AppResult SDL_AppInit(void **appstate, int argc, char *argv[])
{
    App *myApp = (App *)SDL_malloc(sizeof(App));
    *appstate = myApp; // This makes the pointer available to all other callbacks

    if (!SDL_Init(SDL_INIT_VIDEO))
        return SDL_APP_FAILURE;

    SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 1); // Enable MULTISAMPLE
    SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES, 2); // can be 2, 4, 8 or 16
    SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 0);

    // WebGL 2 requires GLES 3.0 context
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);

    myApp->window = SDL_CreateWindow("SDL3_image OpenGL", 380, 380, SDL_WINDOW_OPENGL);
    if (!myApp->window)
        return SDL_APP_FAILURE;

    myApp->glContext = SDL_GL_CreateContext(myApp->window);
    if (!myApp->glContext)
        return SDL_APP_FAILURE;

    SDL_GL_SetSwapInterval(1);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
    glCompileShader(vertexShader);

    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
    glCompileShader(fragmentShader);

    myApp->shaderProgram = glCreateProgram();
    glAttachShader(myApp->shaderProgram, vertexShader);
    glAttachShader(myApp->shaderProgram, fragmentShader);
    glLinkProgram(myApp->shaderProgram);
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    glUseProgram(myApp->shaderProgram);

    GLint textureLocation = glGetUniformLocation(myApp->shaderProgram, "ourTexture");
    glUniform1i(textureLocation, 0); // Explicitly set "ourTexture" to use GL_TEXTURE0

    // Setup Geometry
    float vertices[] = {
        0.5f, 0.5f, 0.0f, 1.0f, 1.0f,
        0.5f, -0.5f, 0.0f, 1.0f, 0.0f,
        -0.5f, -0.5f, 0.0f, 0.0f, 0.0f,
        -0.5f, 0.5f, 0.0f, 0.0f, 1.0f
    };
    unsigned int indices[] = { 0, 1, 3, 1, 2, 3 };

    glGenVertexArrays(1, &myApp->VAO);
    glGenBuffers(1, &myApp->VBO);
    glGenBuffers(1, &myApp->EBO);

    glBindVertexArray(myApp->VAO);
    glBindBuffer(GL_ARRAY_BUFFER, myApp->VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, myApp->EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void *)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void *)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glBindVertexArray(0);

    const char *texturePath = "/assets/images/right-arrow.png";
    myApp->textureID = createTexture(texturePath);

    // glClearColor(0.188f, 0.22f, 0.255f, 1.f);
    glClearColor(0.392f, 0.392f, 0.392f, 1.0f);

    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppEvent(void *appstate, SDL_Event *event)
{
    if (event->type == SDL_EVENT_QUIT)
    {
        return SDL_APP_SUCCESS;
    }
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppIterate(void *appstate)
{
    App *myApp = (App *)appstate;

    glClear(GL_COLOR_BUFFER_BIT);

    glUseProgram(myApp->shaderProgram);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, myApp->textureID);
    glBindVertexArray(myApp->VAO);
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);

    SDL_GL_SwapWindow(myApp->window);
    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void *appstate, SDL_AppResult result)
{
    // Cast the pointer back to your struct type
    App *myApp = (App *)appstate;

    // Only clean up if we actually successfully allocated the state
    if (myApp)
    {
        // Destroy SDL objects
        if (myApp->glContext)
        {
            // Delete OpenGL objects
            glDeleteVertexArrays(1, &myApp->VAO);
            glDeleteBuffers(1, &myApp->VBO);
            glDeleteBuffers(1, &myApp->EBO);
            glDeleteProgram(myApp->shaderProgram);
            glDeleteTextures(1, &myApp->textureID);

            SDL_GL_DestroyContext(myApp->glContext);
        }
        if (myApp->window)
            SDL_DestroyWindow(myApp->window);

        // Free the memory we allocated in SDL_AppInit
        SDL_free(myApp);
    }

    // Final shutdown for the SDL subsystem
    SDL_Quit();
}
