#define SDL_MAIN_USE_CALLBACKS 1 // Use callback functions instead of main()

#include <GLES3/gl3.h>
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_mixer/SDL_mixer.h>

const char *vertexShaderSource =
    "#version 300 es\n"
    "layout (location = 0) in vec3 aPosition;\n"
    "void main()\n"
    "{\n"
    "    gl_Position = vec4(aPosition, 1.0);\n"
    "}\n";

const char *fragmentShaderSource =
    "#version 300 es\n"
    "precision mediump float;\n"
    "out vec4 fragColor;\n"
    "void main()\n"
    "{\n"
    "    fragColor = vec4(0.0, 1.0, 0.0, 1.0);\n"
    "}\n";

typedef struct
{
    SDL_Window *window;
    SDL_GLContext glContext;
    unsigned int shaderProgram;
    unsigned int VAO, VBO;
    MIX_Mixer *mixer;
    MIX_Audio *backgroundMusic;
    MIX_Audio *soundEffect;
    MIX_Track *musicTrack;
    MIX_Track *sfxTrack;
    bool musicStarted;
} App;

SDL_AppResult SDL_AppInit(void **appstate, int argc, char *argv[])
{
    App *myApp = (App *)SDL_malloc(sizeof(App));
    *appstate = myApp; // This makes the pointer available to all other callbacks

    if (!SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO))
        return SDL_APP_FAILURE;

    if (!MIX_Init())
        return SDL_APP_FAILURE;

    // Create the central Mixer Device
    myApp->mixer = MIX_CreateMixerDevice(SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK, NULL);
    if (!myApp->mixer)
        return SDL_APP_FAILURE;

    // WebGL 2 requires GLES 3.0 context
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);

    myApp->window = SDL_CreateWindow("SDL3 Wasm OpenGL", 380, 380, SDL_WINDOW_OPENGL);
    if (!myApp->window)
        return SDL_APP_FAILURE;

    myApp->glContext = SDL_GL_CreateContext(myApp->window);
    if (!myApp->glContext)
        return SDL_APP_FAILURE;

    SDL_GL_SetSwapInterval(1);

    unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
    glCompileShader(vertexShader);

    unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
    glCompileShader(fragmentShader);

    myApp->shaderProgram = glCreateProgram();
    glAttachShader(myApp->shaderProgram, vertexShader);
    glAttachShader(myApp->shaderProgram, fragmentShader);
    glLinkProgram(myApp->shaderProgram);
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    float vertices[] = {
        -0.5f, -0.5f, 0.0f,
        0.5f, -0.5f, 0.0f,
        0.0f, 0.5f, 0.0f
    };

    glGenVertexArrays(1, &myApp->VAO);
    glGenBuffers(1, &myApp->VBO);
    glBindVertexArray(myApp->VAO);
    glBindBuffer(GL_ARRAY_BUFFER, myApp->VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void *)0);
    glEnableVertexAttribArray(0);

    // Load Audio Objects (using 'true' to cache data in memory)
    myApp->backgroundMusic = MIX_LoadAudio(myApp->mixer, "/assets/audio/Winds Of Stories.ogg", true);
    if (!myApp->backgroundMusic)
    {
        SDL_Log("Failed to load music: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    myApp->soundEffect = MIX_LoadAudio(myApp->mixer, "/assets/audio/Picked Coin Echo 2.wav", true);
    if (!myApp->soundEffect)
    {
        SDL_Log("Failed to load sound effect: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    // Allocate dedicated playback tracks
    myApp->musicTrack = MIX_CreateTrack(myApp->mixer);
    myApp->sfxTrack = MIX_CreateTrack(myApp->mixer);
    if (!myApp->musicTrack || !myApp->sfxTrack)
    {
        SDL_Log("Failed to create playback tracks");
        return SDL_APP_FAILURE;
    }

    // Setup and stream background music infinitely
    myApp->musicStarted = false;
    MIX_SetTrackAudio(myApp->musicTrack, myApp->backgroundMusic);

    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppEvent(void *appstate, SDL_Event *event)
{
    App *myApp = (App *)appstate;

    // Handle initial music trigger on any input
    bool isInput = (event->type == SDL_EVENT_KEY_DOWN ||
                    event->type == SDL_EVENT_MOUSE_BUTTON_DOWN);

    if (!myApp->musicStarted && isInput)
    {
        MIX_PlayTrack(myApp->musicTrack, 0);
        myApp->musicStarted = true;
    }

    if (myApp->musicStarted && !MIX_TrackPlaying(myApp->musicTrack))
    {
        // If it stopped, restart it manually
        MIX_PlayTrack(myApp->musicTrack, 0);
    }

    switch (event->type)
    {
        case SDL_EVENT_QUIT:
            return SDL_APP_SUCCESS;

        case SDL_EVENT_KEY_DOWN:
            if (event->key.key == SDLK_SPACE)
            {
                // Instantly bind and fire the one-shot sound effect (0 additional loops)
                MIX_SetTrackAudio(myApp->sfxTrack, myApp->soundEffect);
                MIX_PlayTrack(myApp->sfxTrack, 0);
            }
            break;

        case SDL_EVENT_MOUSE_BUTTON_DOWN:
            // Check if the left mouse button was clicked
            if (event->button.button == SDL_BUTTON_LEFT)
            {
                MIX_SetTrackAudio(myApp->sfxTrack, myApp->soundEffect);
                MIX_PlayTrack(myApp->sfxTrack, 0);
            }
            break;

        default:
            break;
    }
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppIterate(void *appstate)
{
    App *myApp = (App *)appstate;

    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glUseProgram(myApp->shaderProgram);
    glBindVertexArray(myApp->VAO);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    SDL_GL_SwapWindow(myApp->window);
    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void *appstate, SDL_AppResult result)
{
    // Cast the pointer back to your struct type
    App *myApp = (App *)appstate;

    // Only clean up if we actually successfully allocated the state
    if (myApp)
    {
        // Destroy OpenGL objects
        if (myApp->glContext)
        {
            glDeleteVertexArrays(1, &myApp->VAO);
            glDeleteBuffers(1, &myApp->VBO);
            glDeleteProgram(myApp->shaderProgram);
            SDL_GL_DestroyContext(myApp->glContext);
        }

        // Destroy Audio objects
        if (myApp->musicTrack)
            MIX_DestroyTrack(myApp->musicTrack);
        if (myApp->sfxTrack)
            MIX_DestroyTrack(myApp->sfxTrack);
        if (myApp->backgroundMusic)
            MIX_DestroyAudio(myApp->backgroundMusic);
        if (myApp->soundEffect)
            MIX_DestroyAudio(myApp->soundEffect);
        if (myApp->mixer)
            MIX_DestroyMixer(myApp->mixer);

        // Destroy SDL Window
        if (myApp->window)
            SDL_DestroyWindow(myApp->window);

        // Free the memory we allocated in SDL_AppInit
        SDL_free(myApp);
    }

    // In SDL_mixer 3, MIX_Quit() handles garbage collection,
    // but explicit cleanup above is recommended as best practice
    MIX_Quit();

    // Final shutdown for the SDL subsystem
    SDL_Quit();
}
