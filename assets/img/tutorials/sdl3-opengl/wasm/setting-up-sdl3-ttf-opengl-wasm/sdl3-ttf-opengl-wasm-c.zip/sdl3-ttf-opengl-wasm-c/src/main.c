#define SDL_MAIN_USE_CALLBACKS 1 // Use callback functions instead of main()

#include <GLES3/gl3.h>
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <cglm/cglm.h>

typedef struct
{
    SDL_Window *window;
    SDL_GLContext glContext;
    GLuint shaderProgram;
    GLuint VAO, VBO;
    GLuint textTextureID;
    TTF_Font *font;
    int textW;
    int textH;
    mat4 mvpMatrix;
    GLint uMvpMatrixLocation;
} App;

const char *vertexShaderSource =
    "#version 300 es\n"
    "layout (location = 0) in vec3 aPosition;\n"
    "layout (location = 1) in vec2 aTexCoord;\n"
    "out vec2 vTexCoord;\n"
    "uniform mat4 uMvpMatrix;\n"
    "void main()\n"
    "{\n"
    "    gl_Position = uMvpMatrix * vec4(aPosition, 1.0);\n"
    "    vTexCoord = aTexCoord;\n"
    "}\n";

const char *fragmentShaderSource =
    "#version 300 es\n"
    "precision mediump float;\n"
    "in vec2 vTexCoord;\n"
    "uniform sampler2D ourTexture;\n"
    "out vec4 fragColor;\n"
    "void main()\n"
    "{\n"
    "    fragColor = texture(ourTexture, vTexCoord);\n"
    "}\n";

static GLuint createTextureFromSurface(SDL_Surface *surface)
{
    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, surface->w, surface->h,
        0, GL_RGBA, GL_UNSIGNED_BYTE, surface->pixels);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    return texture;
}

SDL_AppResult SDL_AppInit(void **appstate, int argc, char *argv[])
{
    App *myApp = (App *)SDL_malloc(sizeof(App));
    *appstate = myApp; // This makes the pointer available to all other callbacks

    if (!SDL_Init(SDL_INIT_VIDEO))
        return SDL_APP_FAILURE;

    if (!TTF_Init())
        return SDL_APP_FAILURE;

    SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 1); // Enable MULTISAMPLE
    SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES, 2); // can be 2, 4, 8 or 16
    SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 0);

    // WebGL 2 requires GLES 3.0 context
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);

    myApp->window = SDL_CreateWindow("SDL3_ttf OpenGL", 380, 380, SDL_WINDOW_OPENGL);
    if (!myApp->window)
        return SDL_APP_FAILURE;

    myApp->glContext = SDL_GL_CreateContext(myApp->window);
    if (!myApp->glContext)
        return SDL_APP_FAILURE;

    SDL_GL_SetSwapInterval(1);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
    glCompileShader(vertexShader);

    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
    glCompileShader(fragmentShader);

    myApp->shaderProgram = glCreateProgram();
    glAttachShader(myApp->shaderProgram, vertexShader);
    glAttachShader(myApp->shaderProgram, fragmentShader);
    glLinkProgram(myApp->shaderProgram);
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    glUseProgram(myApp->shaderProgram);

    myApp->uMvpMatrixLocation = glGetUniformLocation(myApp->shaderProgram, "uMvpMatrix");

    GLint textureLocation = glGetUniformLocation(myApp->shaderProgram, "ourTexture");
    glUniform1i(textureLocation, 0); // Explicitly set "ourTexture" to use GL_TEXTURE0

    // VAO/VBO Setup (Unit Quad 0.0 to 1.0)
    float vertices[] = {
        // x, y, u, v (flipped)
        -0.5f, 0.5f, 0.0f, 0.0f,
        0.5f, -0.5f, 1.0f, 1.0f,
        -0.5f, -0.5f, 0.0f, 1.0f,

        -0.5f, 0.5f, 0.0f, 0.0f,
        0.5f, 0.5f, 1.0f, 0.0f,
        0.5f, -0.5f, 1.0f, 1.0f
    };
    glGenVertexArrays(1, &myApp->VAO);
    glGenBuffers(1, &myApp->VBO);
    glBindVertexArray(myApp->VAO);
    glBindBuffer(GL_ARRAY_BUFFER, myApp->VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // Stride is 4 floats (x, y, u, v) = 16 bytes
    GLsizei stride = 4 * sizeof(float);

    // Position (Location 0, 2 components: x, y)
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride, (void *)0);
    glEnableVertexAttribArray(0);

    // Texture Coordinates (Location 1, 2 components: u, v)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void *)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);

    // Load Font
    myApp->font = TTF_OpenFont("/assets/fonts/LiberationSans-Regular.ttf", 36.0f);
    if (!myApp->font)
    {
        SDL_Log("Font error: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    // Render text to surface, then to GL texture
    SDL_Color color = { 170, 255, 195, 255 };
    SDL_Surface *s = TTF_RenderText_Blended_Wrapped(myApp->font,
        "Hello, SDL3 and OpenGL ES 3.0!\n\nПривет, SDL3 и OpenGL ES 3.0!", 0, color, 0);
    if (s)
    {
        // Convert surface to a guaranteed RGBA format
        SDL_Surface *converted = SDL_ConvertSurface(s, SDL_PIXELFORMAT_RGBA32);
        SDL_DestroySurface(s); // Free the original

        if (converted)
        {
            myApp->textW = converted->w;
            myApp->textH = converted->h;
            myApp->textTextureID = createTextureFromSurface(converted);
            SDL_DestroySurface(converted);
        }
    }

    // Set coordinate system range: [-100, 100] on both axes
    mat4 projMatrix;
    float viewSize = 300.0f;
    glm_ortho(-viewSize, viewSize, -viewSize, viewSize, -1.0f, 1.0f, projMatrix);

    // View matrix (camera looking at origin)
    mat4 viewMatrix;
    vec3 eye = { 0.0f, 0.0f, 1.0f };
    vec3 center = { 0.0f, 0.0f, 0.0f };
    vec3 up = { 0.0f, 1.0f, 0.0f };
    glm_lookat(eye, center, up, viewMatrix);

    // Model matrix
    mat4 modelMatrix;
    glm_mat4_identity(modelMatrix);
    vec3 translatePos = { 0.0f, 0.0f, 0.0f };
    glm_translate(modelMatrix, translatePos);
    // glm_rotate_z(modelMatrix, glm_rad(30.0f), modelMatrix);
    vec3 scaleFactors = { (float)myApp->textW, (float)myApp->textH, 1.0f };
    glm_scale(modelMatrix, scaleFactors);

    // Set MVP-matrix (Model View Project)
    mat4 projViewMatrix;
    glm_mat4_mul(projMatrix, viewMatrix, projViewMatrix);
    glm_mat4_mul(projViewMatrix, modelMatrix, myApp->mvpMatrix);

    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);

    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppEvent(void *appstate, SDL_Event *event)
{
    if (event->type == SDL_EVENT_QUIT)
    {
        return SDL_APP_SUCCESS;
    }
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppIterate(void *appstate)
{
    App *myApp = (App *)appstate;

    glClear(GL_COLOR_BUFFER_BIT);

    glUseProgram(myApp->shaderProgram);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, myApp->textTextureID);
    glBindVertexArray(myApp->VAO);
    glUniformMatrix4fv(myApp->uMvpMatrixLocation, 1, GL_FALSE,
        (const GLfloat *)myApp->mvpMatrix);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glBindVertexArray(0);

    SDL_GL_SwapWindow(myApp->window);
    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void *appstate, SDL_AppResult result)
{
    // Cast the pointer back to your struct type
    App *myApp = (App *)appstate;

    // Only clean up if we actually successfully allocated the state
    if (myApp)
    {
        // Destroy SDL objects
        if (myApp->glContext)
        {
            // Delete OpenGL objects
            glDeleteVertexArrays(1, &myApp->VAO);
            glDeleteBuffers(1, &myApp->VBO);
            glDeleteProgram(myApp->shaderProgram);
            glDeleteTextures(1, &myApp->textTextureID);
            SDL_GL_DestroyContext(myApp->glContext);
        }
        if (myApp->window)
            SDL_DestroyWindow(myApp->window);

        TTF_CloseFont(myApp->font);
        SDL_free(myApp);
    }

    SDL_Quit();
    TTF_Quit();
}
