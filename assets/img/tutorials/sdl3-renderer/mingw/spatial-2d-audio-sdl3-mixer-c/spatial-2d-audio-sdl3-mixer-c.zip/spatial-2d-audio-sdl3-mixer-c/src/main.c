#define SDL_MAIN_USE_CALLBACKS 1
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_mixer/SDL_mixer.h>
#include <math.h>

// Размеры окна
#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600

// Структуры для игровых объектов
typedef struct
{
    float x, y;
    float size;
    float speed;
    float angle; // Куда смотрит игрок (в радианах)
} Player;

typedef struct
{
    float x, y;
    float size;
    float maxSoundDistance;
} SoundSource;

// Глобальные переменные (в реальном проекте лучше упаковать в appstate)
static SDL_Window *window = NULL;
static SDL_Renderer *renderer = NULL;
static MIX_Mixer *mixer = NULL;
static MIX_Audio *audio = NULL;
static MIX_Track *track = NULL;

static Player player;
static SoundSource coin;

// Состояние нажатых клавиш
static bool keys[SDL_SCANCODE_COUNT] = { false };

// Функция обновления звука на основе 2D координат
void Update2DSound(MIX_Track *track, Player p, SoundSource src)
{
    // Расчет расстояния и громкости
    float dx = src.x - p.x;
    float dy = src.y - p.y;
    float distance = sqrtf(dx * dx + dy * dy);

    float volume = 0.0f;
    if (distance < src.maxSoundDistance)
    {
        volume = 1.0f - (distance / src.maxSoundDistance);
    }

    // Защита от "засыпания" трека.
    // Если volume равен 0, ставим ничтожно малое число.
    // Трек продолжит крутиться в фоне.
    if (volume <= 0.0f)
    {
        volume = 0.0001f;
    }

    // Общая громкость (усиление) трека
    MIX_SetTrackGain(track, volume);

    // Перед return сначала сбрасываем стерео-баланс в центр,
    // чтобы микшер корректно обрабатывал «тишину» в цикле.
    // Сравниваем со значением отсечки безопасности.
    if (volume <= 0.0001f || distance < 0.1f)
    {
        MIX_StereoGains flatGains = { 1.0f, 1.0f };
        MIX_SetTrackStereo(track, &flatGains);
        return;
    }

    // Расчет баланса левого и правого каналов
    float viewX = cosf(p.angle);
    float viewY = sinf(p.angle);
    float soundX = dx / distance;
    float soundY = dy / distance;

    // Косое произведение: < 0 (слева), > 0 (справа)
    float cross = (viewX * soundY) - (viewY * soundX);

    // Создаем структуру для хранения коэффициентов громкости каналов
    MIX_StereoGains gains;

    // Минимальный порог звука для противоположного уха (20%)
    // Благодаря этому противоположное ухо никогда не замолкнет полностью
    float minStereoLeak = 0.2f; // Утечка звука
    // Замечание. Значение minStereoLeak можно крутить в пределах от
    // 0.1f до 0.3f, подбирая наиболее приятный на слух баланс

    if (cross > 0.0f)
    {
        // Источник справа: левое ухо затухает, но не ниже порога minStereoLeak,
        // а правое горит на максимум (1.0)
        // cross на максимуме равен 1.0 (когда объект строго справа под 90 градусов)
        gains.left = 1.0f - (cross * (1.0f - minStereoLeak));
        gains.right = 1.0f;
    }
    else
    {
        // Источник слева: правое ухо затухает, но не ниже порога minStereoLeak,
        // а левое на максимум
        // Поскольку cross отрицательный, используем fabsf() или + cross
        gains.left = 1.0f;
        gains.right = 1.0f + (cross * (1.0f - minStereoLeak));
    }

    // Защита от выхода за пределы [0.0, 1.0]
    if (gains.left < 0.0f)
        gains.left = 0.0f;
    if (gains.right < 0.0f)
        gains.right = 0.0f;

    // Передаем указатель на структуру в функцию SDL3 Mixer
    MIX_SetTrackStereo(track, &gains);
}

void DrawCircle(SDL_Renderer *r, float centerX, float centerY, float radius, int segments)
{
    float angleStep = (2.0f * (float)M_PI) / (float)segments;

    // Задаем начальную точку (при угле = 0)
    float prevX = centerX + radius;
    float prevY = centerY;

    for (int i = 1; i <= segments; i++)
    {
        float angle = (float)i * angleStep;
        float nextX = centerX + cosf(angle) * radius;
        float nextY = centerY + sinf(angle) * radius;

        // Соединяем предыдущую точку с текущей
        SDL_RenderLine(r, prevX, prevY, nextX, nextY);

        prevX = nextX;
        prevY = nextY;
    }
}

SDL_AppResult SDL_AppInit(void **appstate, int argc, char *argv[])
{
    if (!SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO))
    {
        return SDL_APP_FAILURE;
    }

    if (!MIX_Init())
    {
        return SDL_APP_FAILURE;
    }

    // Создаем окно и рендерер одной функцией в SDL3
    if (!SDL_CreateWindowAndRenderer("SDL3 2D Spatial Audio", SCREEN_WIDTH, SCREEN_HEIGHT, 0, &window, &renderer))
    {
        return SDL_APP_FAILURE;
    }

    mixer = MIX_CreateMixerDevice(SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK, NULL);
    if (!mixer)
    {
        return SDL_APP_FAILURE;
    }

    // Загружаем зацикленный звук (например, фоновый гул от объекта или тиканье)
    audio = MIX_LoadAudio(mixer, "assets/audio/Picked Coin Echo 2.wav", true);
    if (!audio)
    {
        SDL_Log("Load failed: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    track = MIX_CreateTrack(mixer);
    if (!track)
        return SDL_APP_FAILURE;

    MIX_SetTrackAudio(track, audio);
    MIX_SetTrackLoops(track, -1); // -1 означает бесконечный повтор звука

    // Инициализация игрока
    player.x = 150.0f;
    player.y = 250.0f;
    player.size = 20.0f;
    player.speed = 150.0f;  // пикселей в секунду
    player.angle = -M_PI_2; // смотрит вверх по умолчанию (-90 градусов)

    // Инициализация источника звука (в правой верхней части)
    coin.x = 600.0f;
    coin.y = 150.0f;
    coin.size = 15.0f;
    coin.maxSoundDistance = 400.0f; // Радиус слышимости звука

    // Принудительно обновляем 3D параметры звука под стартовые позиции
    Update2DSound(track, player, coin);

    // Запускаем трек
    MIX_PlayTrack(track, 0);

    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppEvent(void *appstate, SDL_Event *event)
{
    if (event->type == SDL_EVENT_QUIT)
    {
        return SDL_APP_SUCCESS;
    }

    // Считываем нажатия клавиш
    if (event->type == SDL_EVENT_KEY_DOWN)
    {
        keys[event->key.scancode] = true;
    }
    if (event->type == SDL_EVENT_KEY_UP)
    {
        keys[event->key.scancode] = false;
    }

    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppIterate(void *appstate)
{
    // В SDL3 для плавной анимации мы получаем delta_time (время кадра) напрямую
    static Uint64 last_time = 0;
    if (last_time == 0)
        last_time = SDL_GetTicks();
    Uint64 current_time = SDL_GetTicks();
    float dt = (current_time - last_time) / 1000.0f;
    last_time = current_time;

    // Обработка ввода и движение
    // Движение (WASD и стрелки)
    if (keys[SDL_SCANCODE_W] || keys[SDL_SCANCODE_UP])
        player.y -= player.speed * dt;
    if (keys[SDL_SCANCODE_S] || keys[SDL_SCANCODE_DOWN])
        player.y += player.speed * dt;
    if (keys[SDL_SCANCODE_A] || keys[SDL_SCANCODE_LEFT])
        player.x -= player.speed * dt;
    if (keys[SDL_SCANCODE_D] || keys[SDL_SCANCODE_RIGHT])
        player.x += player.speed * dt;

    // Вращение взгляда игрока (например, на клавиши Q и E)
    // Чтобы вы могли проверить, как меняется панорама при повороте "головы"
    if (keys[SDL_SCANCODE_Q])
        player.angle -= 3.0f * dt; // поворот против часовой
    if (keys[SDL_SCANCODE_E])
        player.angle += 3.0f * dt; // поворот по часовой

    // Проверяем, не закончился ли наш короткий сэмпл.
    // Если он остановился — запускаем его заново, создавая эффект петли (loop)
    if (!MIX_TrackPlaying(track))
    {
        MIX_PlayTrack(track, 0);
    }

    // Обновление звука
    Update2DSound(track, player, coin);

    // Рендеринг (отрисовка)
    // Очищаем экран (черный цвет)
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);

    // Рисуем радиус слышимости источника звука (серая окружность из 64 отрезков)
    SDL_SetRenderDrawColor(renderer, 100, 100, 100, 255);
    DrawCircle(renderer, coin.x, coin.y, coin.maxSoundDistance, 64);

    // Рисуем источник звука (Зеленый квадрат)
    SDL_FRect coinRect = { coin.x - coin.size / 2, coin.y - coin.size / 2, coin.size, coin.size };
    SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
    SDL_RenderFillRect(renderer, &coinRect);

    // Рисуем Игрока (Синий квадрат)
    SDL_FRect playerRect = { player.x - player.size / 2, player.y - player.size / 2, player.size, player.size };
    SDL_SetRenderDrawColor(renderer, 0, 100, 255, 255);
    SDL_RenderFillRect(renderer, &playerRect);

    // Рисуем "линию взгляда" игрока (Красная линия), чтобы видеть куда он повернут
    float lineLength = 25.0f;
    float targetX = player.x + cosf(player.angle) * lineLength;
    float targetY = player.y + sinf(player.angle) * lineLength;
    SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
    SDL_RenderLine(renderer, player.x, player.y, targetX, targetY);

    SDL_RenderPresent(renderer);

    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void *appstate, SDL_AppResult result)
{
    MIX_Quit();
}
