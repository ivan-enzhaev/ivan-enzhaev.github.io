# spatial-2d-audio-sdl3-mixer-c

A project template demonstrating how to implement 2D spatial audio and volume attenuation based on player coordinates in SDL3 using the `SDL3_mixer` extension library, MinGW 13.1, and CMake.

## 📖 Full Tutorial

For complete step-by-step instructions, a breakdown of the math behind stereo panning (cross product), and environment setup details, follow the full guide here:

👉 **[2D Spatial Audio in SDL3 with find_package (MinGW)](https://ivan-enzhaev.github.io/tutorials/sdl3-renderer/mingw/spatial-2d-audio-sdl3-mixer-mingw/?lang=en)**

*Читать на русском:* **[Пространственный 2D-звук в SDL3 с помощью find_package (MinGW)](https://ivan-enzhaev.github.io/tutorials/sdl3-renderer/mingw/spatial-2d-audio-sdl3-mixer-mingw/?lang=ru)**

## 🚀 Quick Start

If you already have your development environment configured:

1. Clone the repository.
2. Ensure you have the required libraries in place:
* SDL3 development files at `C:/libs/SDL3-devel-3.4.8-mingw`
* SDL3_mixer development files at `C:/libs/SDL3_mixer-devel-3.2.2-mingw`
* Runtime binaries (DLLs) added to your system **Path** variable.


3. Place the audio asset inside the project structure:
* Extract `Picked Coin Echo 2.wav` into the `assets/audio/` directory.


4. Use the provided automation scripts to manage your build:
* `config-exe.bat` — Configures the project via CMake using MinGW Makefiles.
* `build-exe.bat` — Compiles the binary and copies the assets to the distribution folder.
* `run-exe.bat` — Launches the compiled executable (`app.exe`).



## 📁 Project Structure

```
spatial-2d-audio-sdl3-mixer-c/ (or -cpp)
├── CMakeLists.txt
├── assets/
│   └── audio/
│       └── Picked Coin Echo 2.wav
└── src/
    └── main.c                 (or main.cpp)

```

## 🎮 Controls

Once the application is running, you can move the player around to test the spatial audio attenuation and balance:

* **W, A, S, D** (or **Arrow Keys**) — Move the Player (Blue square).
* **Q / E** — Rotate the player's vector line of sight (Red line) to test real-time stereo panning changes.

## 🎵 Assets Attribution

This project uses the following free audio asset for spatial testing:

* **Sound Effect:** `Picked Coin Echo 2` by wobbleboxx — [Original Source on OpenGameArt](https://opengameart.org/content/picked-coin-echo-2)
